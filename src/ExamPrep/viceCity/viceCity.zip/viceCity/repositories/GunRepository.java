package viceCity.repositories;

import viceCity.models.guns.Gun;

import java.util.ArrayList;
import java.util.Collection;


public class GunRepository {
    private Collection<Gun> guns;

    public GunRepository() {
        this.guns = new ArrayList<Gun>();
    }
}
