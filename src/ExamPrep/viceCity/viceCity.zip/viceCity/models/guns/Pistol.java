package viceCity.models.guns;

public class Pistol extends BaseGun{
     private static final int BULLETS_PER_BARREL = 50;
     private static final int TOTAL_BULLETS = 500;

    protected Pistol(String name) {
        super(name, BULLETS_PER_BARREL, TOTAL_BULLETS);
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getBulletsPerBarrel() {
        return 0;
    }

    @Override
    public boolean canFire() {
        return false;
    }

    @Override
    public int getTotalBullets() {
        return 0;
    }

    @Override
    public int fire() {
        return 0;
    }
}
