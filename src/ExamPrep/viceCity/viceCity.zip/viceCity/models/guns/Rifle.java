package viceCity.models.guns;

public class Rifle extends BaseGun{
    protected Rifle(String name, int bulletsPerBarrel, int totalBullets) {
        super(name, bulletsPerBarrel, totalBullets);
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getBulletsPerBarrel() {
        return 0;
    }

    @Override
    public boolean canFire() {
        return false;
    }

    @Override
    public int getTotalBullets() {
        return 0;
    }

    @Override
    public int fire() {
        return 0;
    }
}
