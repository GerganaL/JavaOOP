package carTrip;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CarTest {

        private Car car;

        @Before
        public  void setCar(){
            this.car = new Car("Ford",50,40,6);
        }


        @Test(expected = IllegalArgumentException.class)
        public void testSetModelNull(){
           car.setModel(null);
        }

        @Test(expected = IllegalArgumentException.class)
        public void testSetModelEmpty(){
           car.setModel("");
        }


        @Test(expected = IllegalArgumentException.class)
        public void testSetFuelAmountThrowsExCantBeMoreThanCapacity(){
          car.setFuelAmount(60);
        }


        @Test
        public void test_setFuelConsumptionPerKmWorkProperly(){
            car.setFuelConsumptionPerKm(5);
            double expected = 5;
            assertEquals(expected,car.getFuelConsumptionPerKm(),0.00);
        }

        @Test(expected = IllegalArgumentException.class)
        public void test_setFuelConsumptionPerKmThrowExCantBeZero(){
            car.setFuelConsumptionPerKm(0);
        }

        @Test(expected = IllegalArgumentException.class)
        public void test_setFuelConsumptionPerKmThrowExCantBeZeroOrBelow(){
            car.setFuelConsumptionPerKm(-5);
        }

        @Test
        public void test_driveWorkProperly(){
            double distance = 3;
            double tripConsumption = distance * car.getFuelConsumptionPerKm();
            double expected = car.getFuelAmount() - tripConsumption;
            String message = "Have a nice trip";

            assertEquals(message,car.drive(distance));
            assertEquals(expected,car.getFuelAmount(),0.00);
        }


        @Test(expected = IllegalStateException.class)
        public void test_driveThrowExTripConsumptionCannotBeBiggerThanFuelAmount(){
            car.drive(50);
        }


        @Test
        public void  test_refuelWorkProperly(){
            double fuel = 10;
            double expected = car.getFuelAmount() + fuel;
            car.refuel(fuel);

            assertEquals(expected,car.getFuelAmount(),0.00);
        }

        @Test(expected = IllegalStateException.class)
        public void test_refuelThrowExCannotRefuelFuelMoreThanThankCapacity(){
            car.refuel(11);
        }


}