package bakery.common.enums;

public enum TableType {
    InsideTable,
    OutsideTable
}
