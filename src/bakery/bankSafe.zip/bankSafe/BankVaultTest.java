package bankSafe;


import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;
import static org.junit.Assert.assertEquals;


public class BankVaultTest {

    private BankVault bankVault;
    private Item item;

    @Before
    public void setUp() {
        bankVault = new BankVault();
        item = new Item("Gigi", "A1");
    }

    @Test
    public void test_addCellWorkProperly() throws OperationNotSupportedException {
        String cell = "B1";
        String id = item.getItemId();
        String expected = "Item:"+id+" saved successfully!";
        assertEquals(expected,bankVault.addItem(cell,item));
        assertEquals(item,bankVault.getVaultCells().get(cell));
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_addCellIsAlreadyTaken() throws OperationNotSupportedException {
        String cell = "B1";
        bankVault.addItem(cell,item);
        bankVault.addItem(cell,item);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_addCellDoesNotExist() throws OperationNotSupportedException {
        String cell = "bi";
        bankVault.addItem(cell,item);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void test_addCellItemExist() throws OperationNotSupportedException {
        String cell = "A1";
        String cell2 = "A2";
        bankVault.addItem(cell,item);
        bankVault.addItem(cell2,item);
    }


    @Test
    public void test_removeItemWorkProperly() throws OperationNotSupportedException {
        String cell = "A1";
        bankVault.addItem(cell,item);
        String id = item.getItemId();
        String expected = "Remove item:"+id+" successfully!";
        assertEquals(expected,bankVault.removeItem(cell,item));
        assertEquals(null,bankVault.getVaultCells().get(cell));

    }

    @Test(expected = IllegalArgumentException.class)
    public void test_removeItemCellDoesntExist() throws OperationNotSupportedException {
       bankVault.removeItem("Gigi",item);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_removeItemDoesntExist() throws OperationNotSupportedException {
        bankVault.removeItem("A2",item);
    }

}