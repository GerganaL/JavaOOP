package bakery.entities.bakedFoods;

public class Cake extends BaseFood{
    public Cake(String name, double portion, double price) {
        super(name, 245, price);
    }
}
