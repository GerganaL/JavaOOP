package bakery.entities.tables;

public class OutsideTable extends BaseTable{
    public OutsideTable(int tableNumber, int capacity, double pricePerPerson) {
        super(tableNumber, capacity, 3.50);
    }

    @Override
    public int getTableNumber() {
        return 0;
    }

    @Override
    public int getCapacity() {
        return 0;
    }

    @Override
    public int getNumberOfPeople() {
        return 0;
    }

    @Override
    public double getPricePerPerson() {
        return 0;
    }

    @Override
    public boolean isReserved() {
        return false;
    }

    @Override
    public double getPrice() {
        return 0;
    }
}
