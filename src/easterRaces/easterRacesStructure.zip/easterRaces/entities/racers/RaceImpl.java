package easterRaces.entities.racers;

import easterRaces.entities.drivers.Driver;

import java.util.ArrayList;
import java.util.Collection;

public abstract class RaceImpl implements Race{
    private String name;
    private int laps;
    private Collection<Driver> drivers;

    protected RaceImpl(String name, int laps){
        setName(name);
        setLaps(laps);
        this.drivers = new ArrayList<>();
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setLaps(int laps) {
        this.laps = laps;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getLaps() {
        return 0;
    }

    @Override
    public Collection<Driver> getDrivers() {
        return null;
    }

    @Override
    public void addDriver(Driver driver) {

    }
}
