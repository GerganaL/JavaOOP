package EXERCISESAbstraction.cardSuits;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Card Suits:
        //Ordinal value: 0; Name value: CLUBS

        System.out.println("Card Suits:");
        CardSuit[] cards = CardSuit.values();
        for (CardSuit card : cards) {
            System.out.printf("Ordinal value: %d; Name value: %s%n",card.ordinal(),card.name());
        }
    }
}
