package EXERCISESAbstraction.trafficLights;

public enum TrafficLightState {
    RED, YELLOW, GREEN
}
