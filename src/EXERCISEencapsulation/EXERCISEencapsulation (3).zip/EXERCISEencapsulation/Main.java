package EXERCISEencapsulation;

import EXERCISEencapsulation.pizzaCalories.Dough;
import EXERCISEencapsulation.pizzaCalories.Pizza;
import EXERCISEencapsulation.pizzaCalories.Topping;
import EXERCISEencapsulation.shoppingSpree.Person;
import EXERCISEencapsulation.shoppingSpree.Product;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] pizzaTokens = scanner.nextLine().split("\\s+");
        String[] doughTokens = scanner.nextLine().split("\\s+");

        try {
            int countOfToppings = Integer.parseInt(pizzaTokens[2]);
            Pizza pizza = new Pizza(pizzaTokens[1],countOfToppings);
            Dough dough = new Dough(doughTokens[1],doughTokens[2], Double.parseDouble(doughTokens[3]));
            pizza.setDough(dough);

            for (int c = 0; c < countOfToppings; c++) {
                String[] toppingsTokens = scanner.nextLine().split("\\s+");
                Topping topping = new Topping(toppingsTokens[1], Double.parseDouble(toppingsTokens[2]));

                pizza.addTopping(topping);
            }

            System.out.println(String.format("%s - %.2f",pizza.getName(),pizza.getOverallCalories()));
        }catch (IllegalAccessError iae){
            System.err.println(iae.getMessage());
        }
    }
}
