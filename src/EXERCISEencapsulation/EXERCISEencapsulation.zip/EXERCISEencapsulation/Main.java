package EXERCISEencapsulation;

public class Main {
}
