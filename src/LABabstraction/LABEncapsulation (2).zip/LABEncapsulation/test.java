package LABEncapsulation;

public class test {
}
