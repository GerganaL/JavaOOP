package LABInheritance;

import LABInheritance.singleInheritance.Dog;

public class Main {
    public static void main(String[] args) {

    }
}
